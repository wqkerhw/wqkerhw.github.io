
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.imageio.ImageIO;

import com.swetake.util.Qrcode;


public class asd {
	public static void main(String args[]) throws Exception{
		int  version= 6;
		int  qrcodesize = 205;
		
		Qrcode qrcode = new Qrcode();
		qrcode.setQrcodeVersion(version);
		qrcode.setQrcodeErrorCorrect('M');
		String content = "http://www.dijiaxueshe.com";
		byte[] data = content.getBytes("utf-8");
		boolean[][] qrdata = qrcode.calQrcode(data);
		BufferedImage bufferedImage = new BufferedImage(qrcodesize,qrcodesize,BufferedImage.TYPE_INT_RGB);
		BufferedImage image = ImageIO.read(new File("C:/Users/Administrator/Desktop/1.jpg"));
		
		Graphics2D gs = bufferedImage.createGraphics();
		
		gs.setBackground(Color.WHITE);
		int rstart =180 ; int gstart = 0; int bstart =0;
		int rend = 0; int gend = 0; int bend =255;
		gs.clearRect(0, 0, qrcodesize, qrcodesize);
		for(int i = 0;i<qrdata.length;i++){
			for(int j =0;j<qrdata.length;j++){
				if(qrdata[i][j]){
					 /*Random a = new Random();
					  int r = a.nextInt(255);
					  int g = a.nextInt(255);
					  int b = a.nextInt(255);*/
						int r = rstart+(rend-rstart)*(i+1)*(j+1)/(qrdata.length*qrdata.length);
						int g = gstart+(gend-gstart)*(i+1)*(j+1)/(qrdata.length*qrdata.length);
						int b = bstart+(bend-bstart)*(i+1)*(j+1)/(qrdata.length*qrdata.length);
						
					  Color color = new Color(r,g,b);
					  gs.setColor(color);
					gs.fillRect(i*5, j*5, 5, 5); 
				}
			}
		}
		int a =60;
	//	int imageSize= qrcodesize/4;
    	int q = (qrcodesize-a)/2;
		gs.drawImage(image,q , q, a, a,null);
		gs.dispose();
		bufferedImage.flush();
		ImageIO.write(bufferedImage,"png",new File("C:/Users/Administrator/Desktop/sd.png"));
		BufferedImage logo = scale("C:/Users/Administrator/Desktop/1.jpg",a,a,true);
		
		
	}
	private static BufferedImage scale(String logopath,int width ,int height,boolean hasFiller) throws Exception{
		double ratio = 0.0;
		File file = new File(logopath);
		BufferedImage srcImage = ImageIO.read(file);
		Image destImage = srcImage.getScaledInstance(width, height, BufferedImage.SCALE_SMOOTH);
		if((srcImage.getHeight()>height) || (srcImage.getWidth()>width)){
			if(srcImage.getHeight()>srcImage.getWidth()){
				ratio = (new Integer(height)).doubleValue()/srcImage.getHeight();
			}else {
				ratio = (new Integer(width)).doubleValue()/srcImage.getWidth();
			}
			AffineTransformOp op = new AffineTransformOp(AffineTransform.getScaleInstance(ratio, ratio), null);
			destImage = op.filter(srcImage, null);
		}
		if(hasFiller){ //����
			BufferedImage image1 = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			Graphics2D graphic = image1.createGraphics();
			graphic.setColor(Color.white);
			graphic.fillRect(0, 0, width, height);
			if(width == destImage.getWidth(null)){
				graphic.drawImage(destImage, 0, (height-destImage.getHeight(null))/2, destImage.getWidth(null),
						destImage.getHeight(null),Color.white,null);
				
			}else{
				graphic.drawImage(destImage, 0, (width-destImage.getWidth(null))/2, destImage.getWidth(null),
						destImage.getHeight(null),Color.white,null);
			}
			graphic.dispose();
			destImage = image1;
			
		}
		return (BufferedImage) destImage;
		
	}

}
